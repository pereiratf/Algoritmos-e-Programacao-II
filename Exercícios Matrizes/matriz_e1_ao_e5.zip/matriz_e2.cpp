#include <iostream>
#define L 3
#define C 5
using namespace std;

int main()
{
    int ma[L][C], mb[L][C], mc[L][C];
    int i,j, soma=0;

    i=0;
    while (i<L){
        j=0;
        while (j<C){
            //cout<<"ma["<<i<<"]["<<j<<"] = ";
            //cin>>ma[i][j];
            ma[i][j]=rand()%10;
            mb[i][j]=rand()%10;
            mc[i][j] = ma[i][j]+mb[i][j];
            j++;
        }
        i=i+1;
    }

    for (i=0; i<L; i++){
        for (j=0; j<C; j++){
            cout<<ma[i][j]<<"\t";
        }
        cout<<"\n";
    }
    cout<<"\n\n";
    for (i=0; i<L; i++){
        for (j=0; j<C; j++){
            cout<<mb[i][j]<<"\t";
        }
        cout<<"\n";
    }
    cout<<"\n\n";
    for (i=0; i<L; i++){
        for (j=0; j<C; j++){
            cout<<mc[i][j]<<"\t";
        }
        cout<<"\n";
    }

    cout<<"\nlinha 2 matriz c\n";
    for (j=0; j<C; j++){
        cout<<mc[2][j]<<"\t";
    }
    cout<<"\nColuna 3 matriz c\n";
    for (i=0; i<L; i++){
        cout<<mc[i][3]<<"\n";
    }





    return 0;
}
