#include <iostream>
#define L 3
#define C 3
using namespace std;

int main()
{
    int matriz[L][C];
    int i,j, soma=0;

    i=0;
    while (i<L){
        j=0;
        while (j<C){
            cout<<"matriz["<<i<<"]["<<j<<"] = ";
            cin>>matriz[i][j];
            j++;
        }
        i=i+1;
    }

    for (i=0; i<L; i++){
        for (j=0; j<C; j++){
            soma=soma+matriz[i][j];
        }
    }
    cout<<"\n\n";


    cout<<"\nSoma: "<<soma<<"\n";

    return 0;
}
