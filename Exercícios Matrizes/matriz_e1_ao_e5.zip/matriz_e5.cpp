#include <iostream>
#define L 4
#define C 4

using namespace std;

int main()
{
    int m[L][C];
    int i,j, ds=0;

    //preencher a matriz
    i=0;
    while (i<L){
        j=0;
        while (j<C){
            //cout<<"ma["<<i<<"]["<<j<<"] = ";
            //cin>>ma[i][j];
            m[i][j]=rand()%100;

            j++;
        }
        i=i+1;
    }

    //imprimir a matriz
    for (i=0; i<L; i++){
        for (j=0; j<C; j++){
            cout<<m[i][j]<<"\t";

        }
        cout<<"\n";
    }
    cout<<"\n\n";

    //encontrar o maior elemento
    for (i=0; i<L; i++){
        ds=ds+m[i][C-1-i];
    }
/**
    solu��o de qualidade inferior, mas ainda solu��o.
    for (i=0; i<L; i++){
        for (j=0; j<C; j++){
            if(i+j == 3){
               ds=ds+m[i][j];
            }
        }
    }
*/
    cout<<"Somatorio Diagonal Secundaria: "<<ds;

    return 0;
}
